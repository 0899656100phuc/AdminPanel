

<?php $__env->startSection('title','hotel'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Thêm khách sạn</h1>
    
    <div class="row">


    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="">Form thông tin </h4>
        </div>
        <div class="card-body">
            <form action="/create-hotel" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Tỉnh thành:</label>
                            <select name="city" class="form-control" id="">
                                <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->id); ?> / <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Tên khách sạn:</label>
                            <input type="text" name="name" class="form-control" id="recipient-name">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Địa chỉ:</label>
                            <input type="text" name="address" class="form-control" id="recipient-name">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Số điện thoại:</label>
                            <input type="text" name="phone" class="form-control" id="recipient-name">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Email:</label>
                            <input type="text" name="email" class="form-control" id="recipient-name">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Số sao:</label>
                            <input type="number" max="6" min="0" name="star_number" class="form-control" id="recipient-name">
                        </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label for="formFileSm" class="form-label">Cover Hình ảnh:</label>
                            <input name="cover_image" class="form-control form-control-sm" id="formFiles" type="file">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="formFileSm" class="form-label">Nhiều hình ảnh nếu có:</label>
                            <input  class="form-control form-control-sm" id="formFiles" type="file" name="images[]" multiple>
                        </div>
                    </div>
                  </div>
                  
                
                
                  <div class="mb-3">
                    <label for="recipient-name" class="col-form-label">Mô tả:</label>
                    <textarea name="description" class="form-control" id="recipient-name" rows="4"></textarea>
                  </div>
                <table class="table table-bordered " id="table">
                    <tr>
                        <th>Dịch vụ</th>
                        <th>Hành động</th>
                    </tr>
                    <tr>
                        <td><input type="text" name="inputs[0][name_service]" placeholder="Enter your service" class="form-control"></td>
                        <td><button type="button" name="add" id="add" class="btn btn-success">Thêm dịch vụ</button></td>
                    </tr>
                </table>
               
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary">Lưu</button>
                    <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-danger">Trở về</a>
                </div>

            </form>
        </div>

    </div>
    
</div>
<script>
    var i=0;
    $('#add').click(function(){
        
        ++i;
        $('#table').append(
            `<tr>
               
                <td>
                    <input type="text" name="inputs[`+i+`][name_service]" placeholder="Enter your service" class="form-control">
                </td>
                <td>
                    <button type="button" name="add" id="add" class="btn btn-danger remove-input-field">remove</button>
                </td>
            </tr>`);
    });
    $(document).on('click', '.remove-input-field', function () {
        $(this).parents('tr').remove();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin_panel\resources\views/admin/hotel/create-hotel.blade.php ENDPATH**/ ?>