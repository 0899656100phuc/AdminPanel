

<?php $__env->startSection('title', 'hotel'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Edit Hotel</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Hotel</li>
        </ol>
        <div class="row">


        </div>

        <div class="card">
            <div class="card-header">
                <h4 class="">Edit Hotel</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('update-city/' . $citys->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>


                    <input type="hidden" name="id" value="<?php echo e($citys->id); ?>" class="form-control"
                        id="recipient-name">
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label"> Name:</label>
                        <input type="text" name="name" value="<?php echo e($citys->name); ?>" class="form-control"
                            id="recipient-name">
                    </div>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Sub name:</label>
                        <input type="text" name="sub_name" value="<?php echo e($citys->sub_name); ?>" class="form-control"
                            id="recipient-name">
                    </div>


                    <div class="mb-3">
                        <label for="formFileSm" class="form-label">Image:</label>
                        <input name="image" value="<?php echo e($citys->image); ?>" class="form-control form-control-sm"
                            id="formFiles" type="file">
                        <img src="<?php echo e('/images/city/' . $citys->image); ?>" width="70" height="70" alt="Image">
                    </div>


                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-danger">Back</a>

                    </div>

                </form>
            </div>

        </div>
    </div>
    <script>
        var i = 0;
        $('#add').click(function() {

            ++i;
            $('#table').append(
                `<tr>
               
                <td>
                    <input type="text" name="inputs[` + i + `][name_service]" placeholder="Enter your service" class="form-control">
                </td>
                <td>
                    <button type="button" name="add" id="add" class="btn btn-danger remove-input-field">remove</button>
                </td>
            </tr>`);
        });
        $(document).on('click', '.remove-input-field', function() {
            $(this).parents('tr').remove();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin_panel\resources\views/admin/city/edit-city.blade.php ENDPATH**/ ?>