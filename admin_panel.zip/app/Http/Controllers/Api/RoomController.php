<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Http\Request;
use App\Models\Room;
use App\Models\BookingDetail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class RoomController extends Controller
{
    public function bookRoom(Request $request){
        $roomId = $request->get('room_id');
        $checkinDate = $request->get('checkin_date');
        $checkoutDate = $request->get('checkout_date');
        $room = Room::find($roomId);


        $booking = new BookingDetail();
        $booking->room_id = $roomId;
        $booking->checkin = $checkinDate;
        $booking->checkout = $checkoutDate;
        $booking->save();

        // Update room status to "booked"
        $room->status = true;
        $room->save();

        $expireTime = Carbon::now()->addMinutes(5);
        $job = (new ReleaseRoomJob($room))->delay($expireTime);
        dispatch($job);
        return response()->json(['message' => 'Room booked successfully'], 200);
    }
    public function confirmPayment(Request $request)
    {
        $bookingId = $request->get('booking_id');
        $booking = BookingDetail::find($bookingId);
        
        if (!$booking) {
            return response()->json(['message' => 'Booking not found'], 404);
        }
        
        $booking->payment_confirmed = true;
        $booking->save();
        
        $room = $booking->room;
        $room->status = false;
        $room->save();
        
        return response()->json(['message' => 'Payment confirmed'], 200);
    }
}
class ReleaseRoomJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    
    protected $room;
    
    public function __construct(Room $room)
    {
        $this->room = $room;
    }
    
    public function handle()
    {
        $room = Room::find($this->room->id);
        
        if ($room && $room->status === true) {
            $room->status = false;
            $room->save();
        }
    }
}
