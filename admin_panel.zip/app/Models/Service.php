<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory;
    protected $table = 'services';
    
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'id',
        'hotel_id',
        'name',

    ];
    public function hotel()
    {
        return $this->belongsTo(Hotel::class);
    }
}
