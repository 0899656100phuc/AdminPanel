<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\BookingDetail;

class Bookings extends Model
{
    use HasFactory;
    protected $table = 'bookings';
    
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'id',
        'start_date',
        'end_date',
        'total_price',
        'status',

    ];
    public function bookingDetail()
    {
        return $this->hasMany(BookingDetail::class);
    }
    
}
