<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App Booking</title>
</head>

<body>

    <div class="card" style="width: 18rem;">

        <table class="card-table table">

            <tbody>
                <tr>
                    <td>Mark</td>
                    <td>Otto</td>

                </tr>
                <tr>
                    <td>Jacob</td>
                    <td>Thornton</td>
                </tr>

            </tbody>
        </table>
    </div>


    <!-- <p>Dear <?php echo e($mailData['customer']->username); ?>,</p>

    <p>Cảm ơn! Đặt phòng của bạn ở <?php echo e($mailData['hotel']->name); ?> đã được xác nhận:</p>

    <ul>
        <li>Booking ID: <?php echo e($mailData['booking']->id); ?></li>
        <li>Start Date: <?php echo e($mailData['booking']->start_date); ?></li>
        <li>End Date: <?php echo e($mailData['booking']->end_date); ?></li>
     
    </ul> -->

    <p>Thank You.</p>
</body>

</html><?php /**PATH C:\xampp\htdocs\AdminPanel\resources\views/admin/email/form.blade.php ENDPATH**/ ?>