
<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card">
        <div class="card-header">
            <h4>Infomation Room
                <a href="./create-room" class="btn btn-primary btn-sm float-end">Add Room</a>
            </h4>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-block"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <table id="myDataTable" class="table table-bordered display">
                <thead>
                    <th>ID</th>
                    <th>Tên phòng</th>
                    <th>Mô tả</th>
                    <th>Trạng thái</th>
                    <th>Chỉnh sửa</th>
                    <th>Xoa</th>

                </thead>
                <tbody>
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->status); ?></td>

                        <td><a href="<?php echo e(url('edit-room/'.$item->id)); ?>" class="btn btn-success">Edit</a></td>
                        <td><a href="<?php echo e(url('delete-hotel/'.$item->id)); ?>" class="btn btn-danger">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AdminPanel\resources\views/admin/room/index.blade.php ENDPATH**/ ?>