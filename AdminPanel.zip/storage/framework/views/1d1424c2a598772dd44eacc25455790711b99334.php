
<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card">
        <div class="card-header">
            <h4>Danh sách đặt phòng khách sạn

            </h4>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-block"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <table id="myDataTable" class="table table-bordered display">
                <thead>
                    <th>ID</th>
                    <th>ID User</th>
                    <th>Tên người đặt</th>

                    <th>Ngày bắt dầu</th>
                    <th>Ngày kết thúc</th>
                    <th>Trạng thái</th>
                    <th>Ngày đặt phòng</th>
                    <th>Tổng tiền</th>


                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->user_id); ?></td>
                        <td><?php echo e($item->customer?->email); ?></td>

                        <td><?php echo e($item->start_date); ?></td>
                        <td><?php echo e($item->end_date); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><?php echo e($item->date_booking); ?></td>
                        <td><?php echo e($item->total_price); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AdminPanel\resources\views/admin/booking/booking.blade.php ENDPATH**/ ?>