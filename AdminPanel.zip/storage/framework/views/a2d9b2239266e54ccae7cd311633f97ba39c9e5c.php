
<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card">
        <div class="card-header">
            <h4>Thông tin khách sạn 
                <a href="./create-hotel" class="btn btn-primary btn-sm float-end">Thêm khách sạn</a>
            </h4>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-block"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <table id="myDataTable"  class="table table-bordered display">
                <thead >
                    <th>ID</th>
                    <th>Tên khách sạn</th>
                    <th>Địa chỉ</th>
                    <th>Điện thoại</th>
                    <th>Số sao</th>
                    <th>Mô tả</th>

                    <th>Image</th>
                    <th>EDIT</th>
                    <th>DELETE</th>

                </thead>
                <tbody>
                    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->address); ?></td>
                            <td><?php echo e($item->phone); ?></td>
                            <td><?php echo e($item->star_number); ?></td>
                            <td class="truncate">
                                <span><?php echo e($item->description); ?></span>
                                <?php if(strlen($item->description) > 150): ?>
                                  <span class="see-more">Xem thêm</span>
                                <?php endif; ?>
                            </td>

                           
                            <td >
                                <img class="" src="<?php echo e(asset('images/hotel/'.$item->image)); ?>" width="100" height="90" alt="img">
                            </td>
                            <td><a href="<?php echo e(url('edit-hotel/'.$item->id)); ?>" class="btn btn-success">Edit</a></td>
                            <td><a href="<?php echo e(url('delete-hotel/'.$item->id)); ?>" class="btn btn-danger">Delete</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
</div>
<script>
    document.querySelectorAll('.see-more').forEach(item => {
      item.addEventListener('click', event => {
        const span = event.target.previousElementSibling;
        span.style.maxHeight = 'none';
        item.style.display = 'none';
      })
    })
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AdminPanel\resources\views/admin/hotel/index.blade.php ENDPATH**/ ?>