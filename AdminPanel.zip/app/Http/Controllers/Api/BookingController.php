<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Hotel;
use App\Models\Room;
use App\Models\Bookings;
use App\Models\BookingDetail;
use App\Models\TypeRoom;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function getUserBookings($userId)
    {
        $customer = Customer::findOrFail($userId);

        $bookings = $customer->bookings()->with('bookingDetailBooking')->get();
        return response()->json($bookings);
    }
    public function getHotelRoomBooking($id)
    {
        $booking = Bookings::where('id', $id)->first();
        $detail = BookingDetail::where('booking_id', $id)->first();
        echo json_encode($detail);
        exit;
        $hotel = Hotel::findOrFail();
        $room = Room::findOrFail();
        $bookings = $room->bookingDetailRoom()->with('bookings')->get();

        $data = [
            'hotel' => $hotel,
            'room' => $room,
            'bookings' => $bookings
        ];

        return response()->json(['data' => $data]);
    }
}
